import { LightningElement } from 'lwc';

export default class DataBindingComponent extends LightningElement {
    Name='Dev Mukhija';
}