import { LightningElement } from 'lwc';

export default class MyFirstComponent extends LightningElement {}