import { LightningElement } from 'lwc';

export default class ListForEachComponent extends LightningElement {
    listofRecords=['Dev','Akshat','Shashikant','Aditya'];
}