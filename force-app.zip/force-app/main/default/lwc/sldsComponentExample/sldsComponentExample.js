import { LightningElement } from 'lwc';

export default class SldsComponentExample extends LightningElement {}