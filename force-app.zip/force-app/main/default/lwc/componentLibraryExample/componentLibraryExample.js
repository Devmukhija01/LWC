import { LightningElement } from 'lwc';

export default class ComponentLibraryExample extends LightningElement {}